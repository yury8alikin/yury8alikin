import React from 'react';
import './index.css';
import treeData from './data.json';
import axios from 'axios';

export function TreeNode(props) {
    return (
        <>{props.nextNode.map((d, i) => {
            return (<>
                <li key={d.name}>{props.counter?`${props.counter}.`:''}{i+1} {d.name}</li>
                {d.childNodes && <ul><TreeNode nextNode={d.childNodes.reverse()} counter={`${props.counter?`${props.counter}.`:''}${i+1}`} /></ul>}
            </>)
        })}</>
    );
}

export default function Tree(props) {
    if (props.list) return (<ul className="tree">
        <TreeNode nextNode={treeData} counter={0} />
    </ul>
    )
    return (<div className="tree">
        root<br />
        &nbsp;&nbsp;&nbsp;&nbsp;ant <br />
        &nbsp;&nbsp;&nbsp;&nbsp;bear <br />
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;cat <br />
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;dog <br />
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;elephant <br />
        &nbsp;&nbsp;&nbsp;&nbsp;frog <br />
    </div>)
}